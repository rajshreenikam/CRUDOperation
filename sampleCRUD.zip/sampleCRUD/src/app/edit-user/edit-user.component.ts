import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css'],
})
export class EditUserComponent {
  user: any = {};

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      const userId = +params['id'];
      this.userService.getUser(userId).subscribe(
        (response: any) => {
          this.user = response.data;
          console.log(this.user);
        },
        (error) => {
          console.error('Error fetching user:', error);
          this.router.navigate(['/users']);
        }
      );
    });
  }

  updateUser(): void {
    const userId = this.user.id;
    this.userService.updateUser(userId, this.user).subscribe(
      () => {
        this.router.navigate(['/users']);
      },
      (error) => {
        console.error('Error updating user:', error);
      }
    );
  }
}
