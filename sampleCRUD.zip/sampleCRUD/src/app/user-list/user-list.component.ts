import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
})
export class UserListComponent {
  greetingText = 'Hello ReqRes users!';
  users: any[] = [];
  currentPage = 1;
  totalPages: number[] = [];

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.getUsers();
  }

  // getUsers(): void {
  //   this.userService.getUsers().subscribe((response: any) => {
  //     this.users = response.data;
  //   });
  // }
  getUsers(): void {
    this.userService
      .getUserspagination(this.currentPage)
      .subscribe((response: any) => {
        this.users = response.data;
        this.totalPages = Array.from(
          { length: response.total_pages },
          (_, i) => i + 1
        );
      });
  }
  changePage(page: number): void {
    this.currentPage = page;
    this.getUsers();
  }
  deleteUser(userId: number): void {
    this.userService.deleteUser(userId).subscribe(() => {
      this.users = this.users.filter((user) => user.id !== userId);
    });
  }

  editUser(userId: number): void {
    this.router.navigate(['/edit-user', userId]);
  }
}
