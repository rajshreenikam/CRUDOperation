import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css'],
})
export class AddUserComponent {
  newUser: any = {};
  selectedFile: File | null = null;
  constructor(private userService: UserService, private router: Router) {}

  addUser(): void {
    const formData = new FormData();
    formData.append('first_name', this.newUser.first_name);
    formData.append('last_name', this.newUser.last_name);
    formData.append('email', this.newUser.email);

    if (this.selectedFile) {
      formData.append('avatar', this.selectedFile, this.selectedFile.name);
    }
    this.userService.addUser(formData).subscribe((response: any) => {
      console.log(formData);
      this.router.navigate(['/users']);
    });
  }

  onFileSelected(event: any): void {
    const files: FileList = event.target.files;
    this.selectedFile = files.item(0);
  }
}
